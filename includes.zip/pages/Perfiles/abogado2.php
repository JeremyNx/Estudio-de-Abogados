<?php include('../../includes/header.php'); ?>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
  crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
  .profile-heading {
    color: #62152d;
    font-weight: 700;
    margin-bottom: 1rem;
  }

  .profile-section-title {
    font-weight: 600;
    font-size: 1.2rem;
    margin-top: 2rem;
    margin-bottom: 0.5rem;
    color: #343a40;
    border-left: 4px solid #62152d;
    padding-left: .75rem;
  }

  .profile-icon {
    color: #62152d;
    width: 20px;
  }

  .linkedin-btn {
    display: inline-flex;
    align-items: center;
    background-color: #62152d;
    color: #fff;
    padding: 0.5rem 1rem;
    border-radius: 30px;
    text-decoration: none;
    transition: background-color 0.3s ease;
  }

  .linkedin-btn:hover {
    background-color: #4c1023;
    color: #fff;
  }

  .linkedin-btn i {
    margin-right: 8px;
  }

  .practice-areas i {
    color: #62152d;
    margin-right: 8px;
    min-width: 20px;
  }

  .back-btn {
    border-color: #62152d;
    color: #62152d;
    transition: all 0.3s ease;
  }

  .back-btn:hover {
    background-color: #62152d;
    color: #fff;
  }
</style>

<section class="py-5 bg-white">
  <div class="container">
    <div class="row g-5 align-items-start">

      <!-- Imagen -->
      <div class="col-md-5">
            <img src="/assets/img/usuarios/IMG_1601.webp" class="img-fluid rounded shadow" alt="Foto Abogado">

      </div>

      <!-- Información -->
      <div class="col-md-7">
        <!-- Nombre y Especialidad -->
        <h2 class="profile-heading">Dr. Alex Daniel Hernández Vásquez</h2>
        <h5 class="text-muted mb-3">Especialista en Derecho Penal</h5>

        <!-- LinkedIn -->
        <p>
          <a href="/assets/img/usuarios/IMG_1601.webp" target="_blank" class="linkedin-btn">
            <i class="fab fa-linkedin"></i> Ver perfil en LinkedIn
          </a>
        </p>

        <!-- Formación -->
        <div class="profile-section">
          <div class="profile-section-title"><i class="fas fa-graduation-cap profile-icon"></i> Formación Académica
          </div>
          <p>Universidad privada San Martin de Porres- Especializado en materia Civil con mención en Responsabilidad
            Contractual y Extracontractual.</p>
        </div>

        <!-- Experiencia -->
        <div class="profile-section">
          <div class="profile-section-title"><i class="fas fa-briefcase profile-icon"></i> Experiencia Laboral</div>
          <p>Con una formación desde los inicios en temas registrales e inmobiliarios posteriormente perfeccionando el
            perfil de temas comerciales y civiles. Ejerciendo cargos en el sector privado como asistente, analista y
            consultor.</p>
        </div>

        <!-- Áreas de Práctica -->
        <div class="profile-section">
          <div class="profile-section-title"><i class="fas fa-balance-scale profile-icon"></i> Áreas de Práctica</div>
          <ul class="list-unstyled practice-areas">
           <li><i class="fas fa-balance-scale"></i> Derecho Civil</li>
  <li><i class="fas fa-user-friends"></i> Derecho de Familia</li>
  <li><i class="fas fa-file-signature"></i> Derecho Procesal</li>
  <li><i class="fas fa-landmark"></i> Derecho Registral</li>
  <li><i class="fas fa-building"></i> Derecho Inmobiliario</li>
  <li><i class="fas fa-piggy-bank"></i> Derecho Financiero</li>



          </ul>
        </div>

        <!-- Botón de regreso -->
        <a href="../equipo.php" class="btn back-btn mt-4">
          <i class="fas fa-arrow-left me-2"></i>Volver al equipo
        </a>
      </div>
    </div>
  </div>
</section>

<?php include('../../includes/footer.php'); ?>